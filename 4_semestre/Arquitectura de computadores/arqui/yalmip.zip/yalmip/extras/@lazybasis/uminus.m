function y = uminus(X)
%PLUS (overloaded)

% Author Johan L�fberg
% $Id: uminus.m,v 1.1 2005-10-12 16:05:54 joloef Exp $

y = -double(X);
