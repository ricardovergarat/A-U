function [pres,dres] = checklmi(F)
%
% CHECKLMI is obsolete. See CHECKSET instead

[pres,dres] = checkset(F);