function s = indicators(F)

s = F.clauses{1}.extra.indicators;