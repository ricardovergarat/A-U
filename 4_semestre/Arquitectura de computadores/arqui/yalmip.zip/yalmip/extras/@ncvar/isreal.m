function res = isreal(Y)
%ISREAL (overloaded)

% Author Johan L�fberg 
% $Id: isreal.m,v 1.1 2006-08-10 18:00:20 joloef Exp $   

res = isreal(Y.basis);
