�function B = colon(F)

B = getbase(set(F));