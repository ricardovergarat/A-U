function p = problemclass(F,h)

% Author Johan L�fberg
% $Id: problemclass.m,v 1.1 2009-05-12 07:33:29 joloef Exp $

p = problemclass(set(F),h);
