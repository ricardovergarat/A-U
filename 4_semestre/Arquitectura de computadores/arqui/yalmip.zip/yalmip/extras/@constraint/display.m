function display(X)

display(set(X));
