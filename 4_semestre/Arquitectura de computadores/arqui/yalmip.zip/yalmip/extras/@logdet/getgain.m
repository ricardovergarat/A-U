function cx = getgain(X)
%display           Overloaded

% Author Johan L�fberg 
% $Id: getgain.m,v 1.1 2004-06-17 08:40:08 johanl Exp $  

cx = X.gain;
