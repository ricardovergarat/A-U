function Q=getbase(X)
%GETBASE Internal function to extract all base matrices

% Author Johan L�fberg 
% $Id: getbase.m,v 1.4 2006-12-13 13:13:32 joloef Exp $  

%Q=double(X.basis);
Q=X.basis;
  
  
      