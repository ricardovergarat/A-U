function sys = sdp2mat(X,solution)
%SDP2MAT Obsolete, use double

% Author Johan L�fberg
% $Id: sdp2mat.m,v 1.2 2004-07-01 11:17:13 johanl Exp $

warning('sdp2mat is obsolete. Use double');
sys = double(X);