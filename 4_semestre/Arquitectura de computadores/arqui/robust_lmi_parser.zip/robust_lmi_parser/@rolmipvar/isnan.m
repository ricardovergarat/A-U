function out = isnan(X)

out = isnan(X.data(1).value);

return