function Z=clean(Z,name)

Z.extra.opname=name;