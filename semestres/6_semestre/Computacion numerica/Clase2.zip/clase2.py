import numpy as np
import sys
"""
https://www.geeksforgeeks.org/python-program-to-convert-floating-to-binary/

https://stackoverflow.com/questions/17574076/what-is-the-difference-between-len-and-sys-getsizeof-methods-in-python
tamanio en bytes


https://www.openbookproject.net/thinkcs/archive/python/thinkcspyesp3e_abandonado/cap02.html
para saber mas
"""
def float_bin(number, places = 3): 
    # split() seperates whole number and decimal  
    # part and stores it in two seperate variables 
    whole, dec = str(number).split(".") 
    # Convert both whole number and decimal   
    # part from string type to integer type 
    whole = int(whole) 
    dec = int (dec) 
    # Convert the whole number part to it's 
    # respective binary form and remove the 
    # "0b" from it. 
    res = bin(whole).lstrip("0b") + "."
    # Iterate the number of times, we want 
    # the number of decimal places to be 
    for x in range(places): 
        # Multiply the decimal value by 2  
        # and seperate the whole number part 
        # and decimal part 
        whole, dec = str((decimal_converter(dec)) * 2).split(".") 
        # Convert the decimal part 
        # to integer again 
        dec = int(dec) 
        # Keep adding the integer parts  
        # receive to the result variable 
        res += whole 
    return res 
# Function converts the value passed as 
# parameter to it's decimal representation 
def decimal_converter(num):  
    while num > 1: 
        num /= 10
    return num


var_int = -32222
var_float= 3.1
var_long = -4
var_string = 's'


print(sys.getsizeof(var_float))


n = input("Enter your floating point value : \n") 
  
# Take user input for the number of 
# decimal places user want result as 
p = 46
  
print(float_bin(n, places = p))

"""
valor en decimal 19.1

valor de decimal se genere por notacion cientifica.
[1.91 , 1 , 10]
1235236174.16736461263
1.23523617416736461263 * 10**(9)
"1.23523617416736461263"
valor decimal ingrese al cambio de notación punto flotante en binario
19.1 - 1001010.10101110  su exponente y su base
[10101.0101, 34 , 2]

"""

"""
para el proximo jueves
la transformación a notación cientfica
[numero de base 10, el exponente, la base ]
la tranformación a punto flotante (en binario)
[numero en binario, el exponente, base]

"""