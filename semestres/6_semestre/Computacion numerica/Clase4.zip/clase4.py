#clase 4 10-09-2020
#implementacion de lo visto en clase 3 y clase 2
#https://matplotlib.org/gallery/lines_bars_and_markers/simple_plot.html
#https://numpy.org/doc/stable/reference/random/generated/numpy.random.rand.html
#https://realpython.com/how-to-use-numpy-arange/
import numpy as np
import matplotlib.pyplot as plt
#todo con numpy
def error_absoluto():
    #| real - punto flotante|
    return 1

def error_relativo():
    #absoluto(real - punto flotante) / (real) 
    return 1

def metrica():#otra metrica
    return 1

def punto_flotante(numero: str,cifras_signifactivas):#transformacion de numero a la cantidad de cifras significativas solo decimal
    #1.122353451243345*10^10
    return numero

def plot_(datos):#2 funciones 1 plot de los valores reales y otro plot para los errores (absoluto y relativo), si no se puede ver bien el relativo del absoluto dividir un por cada plot(grafico)
    data = np.random.randn(1, datos)*10#cambiar por reales
    data2 = np.random.randn(1, datos)*10#cambiar por el punto flotante
    #print(data.shape,data.shape[1],np.arange(start=0, stop=data.shape[1], step=1))
    fig, axs = plt.subplots(1, 1, figsize=(8, 4))
    #axs[1, 0].scatter(data[0], data[1])
    print(data)
    axs.plot(np.arange(start=0, stop=data.shape[1], step=1), data.transpose())
    plt.show()

np.random.rand(3,2)

plot_(1000)
cifras_signifactivas=[2,5,7,10] # 100 ? 
