import numpy as np

def Notacion_cientifica_binaria(numero_real):
    signo = ""
    Lista_partes_numero=[]
    if "-" in numero_real:
        print("hay menos")
        signo = "-"
        Lista_partes_numero = numero_real.split("-")[1].split(".")
    else:
        Lista_partes_numero = numero_real.split(".")
    binario_int = Numero_int_a_binario(Lista_partes_numero[0])
    binario_decimal= Numero_decimal_a_binario(Lista_partes_numero[1])
    #print(binario_int,"-",binario_decimal)
    parte_entera = binario_int
    exponente = len(parte_entera)-1
    return [signo+parte_entera[0]+"."+parte_entera[1:len(parte_entera)]+binario_decimal,2,exponente]

def comprobar (num_int):
    if len(num_int) > 1:
        return True
    else:
        if num_int == "2" or num_int == "3" or num_int == "4" or num_int == "5" or num_int == "6" or num_int == "7" or num_int == "8" or num_int == "9":
            return True
        else:
            return False
def Numero_int_a_binario(num_entero):
    num_int= num_entero
    binario_alverre=[]
    resto_del_for=np.int64(0)
    
    while  comprobar(num_int):
        new_valor = "0"
        divisor=[]
        for i in range(0,len(num_int)):
            dividendo = np.int64(new_valor)*10 + np.int64(num_int[i])
            #print("dividendo",dividendo)
            divisor.append(int(int(dividendo)/int(2)))
            new_valor = str(dividendo%int(2))
            #print("valor_new",new_valor)
        binario_alverre.append(new_valor)
        #print(divisor)
        divisor_string =""
        for ele in divisor:  
            divisor_string += str(ele)   
        num_int=str(int(divisor_string))
    if(num_int == "1"):
        binario_alverre.append(1)
    else:
        binario_alverre.append(0)
    #print(binario_alverre)
    #print(binario_alverre[::-1])
    binario_alverre=binario_alverre[::-1]
    int_str= ""
    for i in range(0,len(binario_alverre)):
        int_str +=str(binario_alverre[i])

    return int_str

def Numero_decimal_a_binario(num_decimal):
    digitos_despues_dela_coma= len(num_decimal)
    num_float = num_decimal
    numeros_binarios=[]
    #print("numero al reves string",num_float[::-1])
    #print(digitos_despues_dela_coma)
    multiplicacion=[]
    reserva = 0
    num_float=num_float[::-1]
    new_float = num_float
    numero_inicial = new_float
    num_iteracion = 2
    while num_float != new_float or num_iteracion != 1:
        #para que entre la primera vez
        multiplicacion=[]
        for i in range (0,len(num_float)):
            new_valor = int(num_float[i])*2 + reserva
            #print(new_valor,str(new_valor % 10) , int(new_valor / 10))
            if new_valor > 9 : 
                multiplicacion.append( str(new_valor % 10))
                reserva = int(new_valor / 10)
            else:
                reserva=0
                multiplicacion.append( str(new_valor))
        multiplicacion.append( str(reserva))
        #print("salida for",multiplicacion)
        # aqui viene el tema de la coma
        numeros_binarios.append( multiplicacion[digitos_despues_dela_coma:len(multiplicacion)])
        
        multiplicacion = multiplicacion[0:digitos_despues_dela_coma]
        multiplicacion = multiplicacion[::-1]
        #print("decimal:",multiplicacion)
        num_float = ""
        for j in range(0,len(multiplicacion)):
            num_float += str(multiplicacion[j])
        #multiplicacion[0:digitos_despues_dela_coma]
        #aqui viene el tema de cambio a string
        num_float = num_float[::-1]
        if(num_float == new_float ):
            num_iteracion = 1

    salida = ""
    for i in range (0,len( numeros_binarios)):
        salida +=numeros_binarios[i][0] 
    
    #print(numeros_binarios)
    return salida


def Notacion_cientifica_decimal(numero_real):
    signo=""
    Lista_partes_numero=[]
    if "-" in numero_real:
        print("hay menos")
        signo = "-"
        Lista_partes_numero = numero_real.split("-")[1].split(".")
    else:
        Lista_partes_numero = numero_real.split(".")
    parte_entera = Lista_partes_numero[0]
    exponente = len(parte_entera)-1
    return [signo+parte_entera[0]+"."+parte_entera[1:len(parte_entera)]+Lista_partes_numero[1],10,exponente]

if __name__ == "__main__":
    Numero_inicial=str(input("Ingrese numero"))
    print(Notacion_cientifica_decimal( Numero_inicial))
    print(Notacion_cientifica_binaria(Numero_inicial))
